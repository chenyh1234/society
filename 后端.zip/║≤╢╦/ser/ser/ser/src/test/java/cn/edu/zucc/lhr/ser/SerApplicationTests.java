package cn.edu.zucc.lhr.ser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerApplicationTests {

    @Test
    void contextLoads() {
    }

}
