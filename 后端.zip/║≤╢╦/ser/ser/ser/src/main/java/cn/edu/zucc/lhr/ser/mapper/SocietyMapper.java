package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Society;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public interface SocietyMapper extends BaseMapper<Society> {

    @Select("select *  from society where soc_name like '%${query}%' limit #{count}, #{pageid}")
    ArrayList<Society> findAllSociety(        @Param("count") Integer count,
                                              @Param("pageid") Integer pageid,
                                              @Param("query") String query);



    @Select("select * from society where soc_id =#{id}")
    Society findOneSocietyById(@Param("id") Integer id);


//    @Update("update member set mem_key =#{pwd} where mem_id=#{id}")
//    void changePassword(@Param("id")  Integer id,
//                       @Param("pwd")  String pwd);
//    soc_id,soc_member_count,soc_alive,soc_introduction,soc_name
    @Insert("insert into society(soc_member_count,soc_alive,soc_introduction,soc_name) " +
            "values(#{socMemberCount},#{socAlive},#{socIntroduction},#{socName})")
    void registerSociety(   @Param("socMemberCount")  Integer socMemberCount,
                            @Param("socAlive") Integer socAlive,
                            @Param("socIntroduction")  String socIntroduction,
                            @Param("socName")  String socName);

    @Select("select count(*)  from society")
    Integer getSocietyTotalNumber();

    @Delete("delete from society where soc_id =#{id}")
    void DeleteSocietyById(@Param("id") Integer id);

//    @Select("select *  from society where soc_name like '%${query}%' limit #{count}, #{pageid}")

    @Select("select a.soc_name,soc_introduction,soc_member_count  " +
            "from society a,member b,society_of_member c " +
            "where c.mem_id=b.mem_id and  a.soc_id= c.soc_id and b.mem_id=#{memId} " +
            "and a.soc_name like '%${query}%' limit #{startid}, #{pagesize}")

    ArrayList<Society> findSocietyByMemId(@Param("memId")String memId,
                                          @Param("startid") Integer startid,
                                          @Param("pagesize") Integer pagesize,
                                          @Param("query") String query);

    @Select("select * from  society a,soc_of_pre b,president c " +
            "where c.pre_id=#{preId} and b.pre_id = c.pre_id and a.soc_id = b.soc_id")
    Society findOneSocietyByPreId(@Param("preId") String preId);

    @Select("select count(*)  from society where soc_name like '%${query}%'")
    Integer calculateTotalNumber(@Param("query") String query);
}
