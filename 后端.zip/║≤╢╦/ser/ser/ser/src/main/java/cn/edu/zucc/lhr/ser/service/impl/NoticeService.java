package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Notice;
import cn.edu.zucc.lhr.ser.mapper.NoticeMapper;
import cn.edu.zucc.lhr.ser.service.INoticeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


@Transactional
@Service
public class NoticeService extends ServiceImpl<NoticeMapper, Notice> implements INoticeService {

    @Autowired
    NoticeMapper noticeMapper;

    @Override
    public ArrayList<Notice>  findAllNoticeDivide(Integer startid, Integer pagesize, String query){
        return noticeMapper.findAllNoticeDivide(startid,pagesize,query);
    }

    @Override
    public ArrayList<Notice> findAllNoticeDivideByPreId(String preId, Integer startid, Integer pagesize, String query) {
        return noticeMapper.findAllNoticeDivideByPreId(preId,startid,pagesize,query);
    }

    @Override
    public Integer calculateTotalNoticeByPreId(String preId, String query) {
        return noticeMapper.calculateTotalNoticeByPreId(preId,query);
    }

    @Override
    public Integer selectMaxNotId() {
        return noticeMapper.selectMaxNotId();
    }

    @Override
    public void deliverNoticeByPreId(String preId, String notContent) {
        noticeMapper.deliverNoticeByPreId(preId,notContent);
    }

    @Override
    public void updateNotForMem(String memId, Integer notId) {
        noticeMapper.updateNotForMem(memId,notId);
    }

    @Override
    public void changeNoticeByNotId(Integer notId, String notContent) {
        noticeMapper.changeNoticeByNotId(notId,notContent);
    }

    @Override
    public void deleteNotForMem(Integer notId) {
        noticeMapper.deleteNotForMem(notId);
    }

    @Override
    public void deleteNotice(Integer notId) {
        noticeMapper.deleteNotice(notId);
    }

    @Override
    public Notice findNoticeByNotId(Integer notId) {
        return noticeMapper.findNoticeByNotId(notId);
    }

    @Override
    public ArrayList<String> findAllMemIdByPreId(String preId) {
        return noticeMapper.findAllMemIdByPreId(preId);
    }
}
