package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public interface NoticeMapper extends BaseMapper<Notice> {

    @Select("select * from notice "+
            "where not_content like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Notice> findAllNoticeDivide(@Param("startid")Integer startid,
                                          @Param("pagesize")Integer pagesize,
                                          @Param("query")String query);


    @Select("select * from notice "+
            "where pre_id=#{preId} and not_content like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Notice> findAllNoticeDivideByPreId(@Param("preId")String preId,
                                                 @Param("startid")Integer startid,
                                                 @Param("pagesize")Integer pagesize,
                                                 @Param("query")String query);
    @Select("select count(*) from notice "+
            "where pre_id=#{preId} and not_content like '%${query}%' ")
    Integer calculateTotalNoticeByPreId(@Param("preId")String preId,
                                        @Param("query") String query);

    @Select("select max(not_id) from notice")
    Integer selectMaxNotId();

    @Insert("insert into notice(pre_id,not_content) values(#{preId},#{notContent})")
    void deliverNoticeByPreId(@Param("preId")String preId,
                              @Param("notContent")String notContent);


    @Insert("insert into not_for_mem (mem_id,not_id) values(#{memId},#{notId})")
    void updateNotForMem(@Param("memId")String memId,
                         @Param("notId")Integer notId);

    @Update("update notice set not_content = #{notContent} where not_id = #{notId}")
    void changeNoticeByNotId(@Param("notId")Integer notId,
                             @Param("notContent")String notContent);

    @Delete("delete from not_for_mem where not_id = #{notId}")
    void deleteNotForMem(@Param("notId")Integer notId);

    @Delete("delete from notice where not_id = #{notId}")
    void deleteNotice(@Param("notId")Integer notId);

    @Select("select * from notice where not_id = #{notId}")
    Notice findNoticeByNotId(@Param("notId")Integer notId) ;

    @Select("select a.mem_id from society_of_member a,society b,soc_of_pre c,president d " +
            "where d.pre_id = #{preId} and  c.pre_id = d.pre_id and b.soc_id = c.soc_id and a.soc_id = b.soc_id")
    ArrayList<String> findAllMemIdByPreId(@Param("preId")String preId);
}
