package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Student;
import cn.edu.zucc.lhr.ser.mapper.StudentMapper;
import cn.edu.zucc.lhr.ser.service.IStudentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


@Transactional
@Service
public class StudentService extends ServiceImpl<StudentMapper, Student> implements IStudentService {

    @Autowired
    StudentMapper studentMapper;
    @Override
    public Student findOneStudentById(String id){return studentMapper.findOneStudentById(id);}

    @Override
    public ArrayList<Student> findAllStudent() {
        return studentMapper.findAllStudent();
    }

    @Override
    public void changePassword(String id, String pwd) {
        studentMapper.changePassword(id, pwd);
    }

    @Override
    public void registerStudent(String id,String name, String pwd) { studentMapper.registerStudent(id,name, pwd);
    }


    @Override
    public Integer selectMaxAppId(){ return studentMapper.selectMaxAppId();
    }

    @Override
    public void updateStuApplication(String stuName,Integer appId) {
        studentMapper.updateStuApplication(stuName,appId);
    }

    @Override
    public String findStuNameByStuId(String stuId) {
        return studentMapper.findStuNameByStuId(stuId);
    }

    @Override
    public void updateStuOfApplication(Integer appId, String stuId) {
        studentMapper.updateStuOfApplication(appId,stuId);
    }

    @Override
    public void updateStuInActivity(String stuId, Integer actId) {
        studentMapper.updateStuInActivity(stuId,actId);
    }

    @Override
    public void updateLimitCountInActivity(Integer actId) {
        studentMapper.updateLimitCountInActivity(actId);
    }

    @Override
    public Student findStudentByAppId(Integer appId) {
        return studentMapper.findStudentByAppId(appId);
    }

    @Override
    public ArrayList<Student> findAllStudentDivide(Integer startid, Integer pagesize, String query) {
        return studentMapper.findAllStudentDivide(startid,pagesize,query);
    }

    @Override
    public Integer calculateTotalStudentNumber(String query) {
        return studentMapper.calculateTotalStudentNumber(query);
    }


    @Override
    public void insertApplication(Integer appId, Integer socId, String appContent, String appStatus) {
        studentMapper.insertApplication(appId,socId,appContent,appStatus);
    }
}
