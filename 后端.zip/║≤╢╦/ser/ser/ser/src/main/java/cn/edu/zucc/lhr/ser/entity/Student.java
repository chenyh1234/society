package cn.edu.zucc.lhr.ser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("student")
public class Student {
    @TableId
    private String stuId;
    private String stuName;
    private String stuKey;

    Student() {

    }

//    public Student(Integer stuId, String stuKey, String stuName){
//        this.stuId = stuId;
//        this.stuName = stuName;
//        this.stuKey = stuKey;
//    }
}
