package cn.edu.zucc.lhr.ser.controller;

import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Member;
import cn.edu.zucc.lhr.ser.entity.Notice;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.service.INoticeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;

@Api(tags = "通知模块")
@RestController
@RequestMapping("/Notice")
public class NoticeController {

    @Resource
    @Autowired
    INoticeService noticeService;

    @ApiOperation(value = "分页列出所有通知")
    @GetMapping("/findAllNoticeDivide")
    public Result queryAllNoticeDivide(@RequestParam("pagesize")Integer pagesize,
                                       @RequestParam("pagenum")Integer pagenum,
                                       @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);

//        Integer total = (getSocietyTotalNumber()-1)/count+1;
        ArrayList<Notice> records = noticeService.findAllNoticeDivide(startid,pagesize,query);
        Integer total = records.size();
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "根据社长id分页列出所有通知")
    @GetMapping("/findAllNoticeDivideByPreId")
    public Result queryAllNoticeDivideByPreId(  @RequestParam("preId")String preId,
                                                @RequestParam("pagesize")Integer pagesize,
                                                @RequestParam("pagenum")Integer pagenum,
                                                @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        ArrayList<Notice> records = noticeService.findAllNoticeDivideByPreId(preId,startid,pagesize,query);
        Integer total = totalNoticeByPreId(preId,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有通知分页显示结果数量(社长)")
    @GetMapping("/calculateTotalNoticeByPreId")
    public Integer totalNoticeByPreId( @RequestParam("preId")String preId,
                                            @RequestParam("query") String query){
        return noticeService.calculateTotalNoticeByPreId(preId,query);

    }
    @ApiOperation(value = "根据通知id找通知对象")
    @GetMapping("/findNoticeByNotId")
    public Result findNoticeByNotId(@RequestParam("notId")Integer notId)
    {
        Notice notice = noticeService.findNoticeByNotId(notId);
        return Result.ok().data("notice",notice);
    }


    @ApiOperation(value = "发布通知(社长)")
    @GetMapping("/deliverNoticeByPreId")
    public Result deliverNoticeByPreId(  @RequestParam("preId")String preId,
                                         @RequestParam("notContent")String notContent){
        noticeService.deliverNoticeByPreId(preId,notContent);
        Integer notId = noticeService.selectMaxNotId();
        ArrayList<String> memIdList= findAllMemIdByPreId(preId);
        for(Integer i = 0; i<memIdList.size(); i++){
            String memId = memIdList.get(i);
            noticeService.updateNotForMem(memId,notId);
        }

        return  Result.ok().data("提示","发布成功");
    }

    public ArrayList<String> findAllMemIdByPreId(String preId) {
        return noticeService.findAllMemIdByPreId(preId);
    }

    @ApiOperation(value = "删除通知(社长)")
    @GetMapping("/deleteNoticeByNotId")
    public Result deleteNoticeByNotId(@RequestParam("notId") Integer notId){
        noticeService.deleteNotForMem(notId);
        noticeService.deleteNotice(notId);
        return Result.ok().data("提示","删除成功");
    }

    @ApiOperation(value = "修改通知(社长)")
    @GetMapping("/changeNoticeByNotId")
    public Result changeNoticeByNotId(@RequestParam("notId") Integer notId,
                                      @RequestParam("notContent") String notContent){
        noticeService.changeNoticeByNotId(notId,notContent);

        return Result.ok().data("提示","修改成功");
    }
}
