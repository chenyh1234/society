package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Society;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;

    public interface ISocietyService extends IService<Society> {

    ArrayList<Society> findAllSociety(Integer startid, Integer size ,String query);

//    void changePassword(Integer id, String pwd);
     Society findOneSocietyById(Integer id);

    void registerSociety(Integer socMemberCount,Integer socAlive,String socIntroduction, String socName);

    Integer getSocietyTotalNumber();

    void DeleteSocietyById(Integer id);

        Society findOneSocietyByPreId(String preId);

        Integer calculateTotalNumber(String query);

//    ArrayList<Society> findSocietyByMemId( String memId,Integer startid,Integer pagesize,String query);
    }
