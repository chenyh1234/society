package cn.edu.zucc.lhr.ser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("activity")
public class Society {
    @TableId
    private Integer socId;
    private Integer socMemberCount;
    private Integer socAlive;
    private String socIntroduction;
    private String socName;

    public Society(){

    }


//    public Society(Integer socId, Integer socMemberCount, Integer socAlive,String socIntroduction,String socName){
//        this.socId=socId;
//        this.socMemberCount =socMemberCount;
//        this.socAlive=socAlive;
//        this.socIntroduction=socIntroduction;
//        this.socName=socName;
//    }
}
