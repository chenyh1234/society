package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Notice;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;

public interface INoticeService extends IService<Notice> {




    ArrayList<Notice> findAllNoticeDivide(Integer startid, Integer pagesize, String query);

    ArrayList<Notice> findAllNoticeDivideByPreId(String preId, Integer startid, Integer pagesize, String query);

    Integer calculateTotalNoticeByPreId(String preId, String query);

    Integer selectMaxNotId();

    void deliverNoticeByPreId(String preId, String notContent);


    void updateNotForMem(String memId, Integer notId);

    void changeNoticeByNotId(Integer notId, String notContent);

    void deleteNotForMem(Integer notId);

    void deleteNotice(Integer notId);

    Notice findNoticeByNotId(Integer notId);

    ArrayList<String> findAllMemIdByPreId(String preId);
}
