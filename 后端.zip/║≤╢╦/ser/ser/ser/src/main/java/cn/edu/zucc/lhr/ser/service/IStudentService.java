package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;

public interface IStudentService extends IService<Student> {

    ArrayList<Student> findAllStudent();

    void changePassword(String id, String pwd);

    Student findOneStudentById(String id);

    void registerStudent(String id,String name, String pwd);

    void insertApplication(Integer appId, Integer socId, String appContent, String appStatus);

    Integer selectMaxAppId();

    void updateStuApplication(String stuName,Integer appId);

    String findStuNameByStuId(String stuId);

    void updateStuOfApplication(Integer appId, String stuId);


    void updateStuInActivity(String stuId, Integer actId);

    void updateLimitCountInActivity(Integer actId);

    Student findStudentByAppId(Integer appId);

    ArrayList<Student> findAllStudentDivide(Integer startid, Integer pagesize, String query);

    Integer calculateTotalStudentNumber(String query);
}
