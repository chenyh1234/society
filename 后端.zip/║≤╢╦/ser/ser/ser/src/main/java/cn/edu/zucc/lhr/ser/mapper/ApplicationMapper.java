package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Application;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Component
public interface ApplicationMapper extends BaseMapper<Application> {


    @Select("select * from application where app_id =#{appId}")
    Application findOneApplicationById(@Param("appId") Integer appId);


//    @Select("select * from activity "+
//            "where act_name like '%${query}%' limit #{startid}, #{pagesize}")
//    ArrayList<Application> findAllActivityDivide(Integer startid, Integer pagesize, String query);
}
