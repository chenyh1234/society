package cn.edu.zucc.lhr.ser.controller;

import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Member;
import cn.edu.zucc.lhr.ser.entity.Notice;
import cn.edu.zucc.lhr.ser.entity.Society;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.service.IMemberService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;

@Api(tags = "社团成员模块")
@RestController
@RequestMapping("/Member")
public class MemberController {

    @Resource
    @Autowired
    IMemberService memberService;

    @ApiOperation(value = "通过社长id分页获取社团成员（社长）")
    @GetMapping("/findAllMemberByPreId")
    public Result queryAllSocietyByPreId(@RequestParam("preId")  String preId,
                                  @RequestParam("pagesize")Integer pagesize,
                                  @RequestParam("pagenum")Integer pagenum,
                                  @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        ArrayList<Member> records = memberService.findAllMemberByPreId(preId,startid,pagesize,query);
        Integer total =totalMemberNumber(preId,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有社团成员查询结果")
    @GetMapping("/calculateTotalMemberNumber")
    public Integer totalMemberNumber(@RequestParam("preId")String preId,
                                     @RequestParam("query") String query){
        return memberService.calculateTotalMemberNumber(preId,query);

    }

    @ApiOperation(value = "通过成员id分页获取成员活动")
    @GetMapping("/findAllActivityByMemId")
    public Result queryAllActivityByMemId(@RequestParam("memId")  String memId,
                                         @RequestParam("pagesize")Integer pagesize,
                                         @RequestParam("pagenum")Integer pagenum,
                                         @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        ArrayList<Activity> records = memberService.findAllActivityByMemId(memId,startid,pagesize,query);
        Integer total = totalActivityNumber(memId,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有社团成员查询结果")
    @GetMapping("/calculateTotalActivityNumber")
    public Integer totalActivityNumber(@RequestParam("memId")  String memId,
                                     @RequestParam("query") String query){
        return memberService.calculateTotalActivityNumber(memId,query);
    }

    @ApiOperation(value = "通过社团成员id获取社团（成员）")
    @GetMapping("/findSocietyByMemId")
    public Result querySocietyByMemId(@RequestParam("memId")  String memId,
                                      @RequestParam("pagesize")Integer pagesize,
                                      @RequestParam("pagenum")Integer pagenum,
                                      @RequestParam("query") String query
    ){
        Integer startid;
        startid=pagesize*(pagenum-1);
        ArrayList<Society> records =memberService.findSocietyByMemId(memId,startid,pagesize,query);
        Integer total = totalSocietyNumber(memId,query);
        return Result.ok().data("total",total).data("records",records);

    }

    @ApiOperation(value = "计算所有社团成员查询结果")
    @GetMapping("/calculateTotalSocietyNumber")
    public Integer totalSocietyNumber(@RequestParam("memId")  String memId,
                                       @RequestParam("query") String query){
        return memberService.calculateTotalSocietyNumber(memId,query);
    }


    @ApiOperation(value = "分页列出所在社团通知（成员）")
    @GetMapping("/findAllNoticeDivideByMemId")
    public Result queryAllNoticeDivideByMemId(@RequestParam("memId")  String memId,
                                            @RequestParam("pagesize")Integer pagesize,
                                            @RequestParam("pagenum")Integer pagenum,
                                            @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);

//        Integer total = (getSocietyTotalNumber()-1)/count+1;
        ArrayList<Notice> records = memberService.findAllNoticeDivideByMemId(memId,startid,pagesize,query);
        Integer total = totalNoticeNumber(memId,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有社团成员查询结果")
    @GetMapping("/calculateTotalNoticeNumber")
    public Integer totalNoticeNumber(@RequestParam("memId")  String memId,
                                      @RequestParam("query") String query){
        return memberService.calculateTotalNoticeNumber(memId,query);
    }

    @ApiOperation(value = "根据成员id社团id删除社团（成员）")
    @GetMapping("/removeSocietyBySocIdAndMemId")
    public Result removeSocietyById(@RequestParam("socId")  String socId,
                                    @RequestParam("memId")  String memId){

        Member member = queryOneMemberById(memId);
        if(member != null){
            memberService.UpdateSocMemberCount(socId);
            memberService.DeleteSocietyBySocIdAndMemId(socId,memId);
            memberService.DeleteMemberByMemId(memId);
            return Result.ok();
        }
        else{
            return Result.error().data("提示", "删除失败");
        }
    }

    @ApiOperation(value = "修改密码")
    @GetMapping("/changePwd")
    public Result changePwd(@RequestParam("memId")String memId,
                            @RequestParam("usedPassword")String usedPassword,
                            @RequestParam("newPassword1")String newPassword1,
                            @RequestParam("newPassword2")String newPassword2){
        Member member = queryOneMemberById(memId);
        if(member == null){

            return Result.error().data("提示","用户名不存在,重新输入");
        }
        else{
            if(usedPassword.equals(member.getMemKey()) && newPassword1.equals(newPassword2)){
                memberService.changePassword(memId, newPassword2);
                return Result.ok();
            }

            else
                return Result.error().data("提示","密码有误,重新输入!");

        }

    }

    @ApiOperation(value = "通过id获取成员")
    @GetMapping("/queryOneMemberById")
    public Member queryOneMemberById(String id){
        return memberService.findOneMemberById(id);
    }


}
