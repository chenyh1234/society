package cn.edu.zucc.lhr.ser.controller;


import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Application;
import cn.edu.zucc.lhr.ser.entity.Student;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.service.IActivityService;
import cn.edu.zucc.lhr.ser.service.IApplicationService;
import cn.edu.zucc.lhr.ser.service.IStudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;

@Api(tags = "学生模块")
@RestController
@RequestMapping("/Student")
public class StudentController {

    @Resource
    @Autowired
    IStudentService studentService;
    @Resource
    @Autowired
    IApplicationService applicationService;
    @Resource
    @Autowired
    IActivityService activityService;
    @ApiOperation(value = "获取所有学生")
    @GetMapping("/findAllStudent")
    public ArrayList<Student> queryAllAdmin(){
        return studentService.findAllStudent();
    }

//返回前端


    @ApiOperation(value = "获取所有学生")
    @GetMapping("/findAllStudentDivide")
    public Result findAllStudent(               @RequestParam("pagesize")Integer pagesize,
                                                @RequestParam("pagenum")Integer pagenum,
                                                @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        ArrayList<Student> records = studentService.findAllStudentDivide(startid,pagesize,query);
        Integer total = calculateTotalStudentNumber(query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有申请分页显示结果数量")
    @GetMapping("/calculateTotalStudentNumber")
    public Integer calculateTotalStudentNumber(
                                                @RequestParam("query") String query){
        return studentService.calculateTotalStudentNumber(query);

    }

    @ApiOperation(value = "通过id获取学生")
    @GetMapping("/queryOneStudentById")
    public Result queryOneStudentById(@RequestParam("stuId")String stuId){

        Student student = studentService.findOneStudentById(stuId);
        return Result.ok().data("student",student);
    }




    @ApiOperation(value = "学生提交加入社团申请")
    @GetMapping("/applyToSociety")
    public Result insertApplication(@RequestParam("stuId")String stuId,
                                    @RequestParam("socId")Integer socId,
                                    @RequestParam("appContent")String appContent,
                                    @RequestParam(value="appStatus",required=true,defaultValue = "等待审核") String appStatus
    ){
        Integer appId=1;
        if(applicationService.findOneApplicationById(appId)!=null){
            appId = studentService.selectMaxAppId()+1;
        }
        else
            appId = 1;
        studentService.insertApplication(appId,socId,appContent,appStatus);
        String stuName = studentService.findStuNameByStuId(stuId);
        studentService.updateStuApplication(stuName,appId);
        studentService.updateStuOfApplication(appId,stuId);
        Application application = applicationService.findOneApplicationById(appId);
        return Result.ok().data("application",application);
    }

    @ApiOperation(value = "根据学生id获取已经报名活动分页显示")
    @GetMapping("/findAllActivityDivideByStuId")
    public Result findAllActivityDivideByStuId( @RequestParam("stuId")String stuId,
                                                @RequestParam("pagesize")Integer pagesize,
                                                @RequestParam("pagenum")Integer pagenum,
                                                @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        Integer total = totalActivityNumberByStuId(stuId,query);
        ArrayList<Activity> records = activityService.findAllActivityDivideByStuId(stuId,startid,pagesize,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算学生所有活动分页显示结果数量")
    @GetMapping("/calculateTotalActivityNumberByStuId")
    public Integer totalActivityNumberByStuId(  @RequestParam("stuId")String stuId,
                                                @RequestParam("query") String query){
        return activityService.calculateTotalActivityNumberByStuId(stuId,query);

    }

    @ApiOperation(value = "学生报名活动")
    @GetMapping("/applyActivity")
    public Result insertActivity(@RequestParam("stuId")String stuId,
                                    @RequestParam("actId")Integer actId

    ){
        studentService.updateStuInActivity(stuId,actId);
        studentService.updateLimitCountInActivity(actId);
        return Result.ok().data("提示","报名成功");
    }

    @ApiOperation(value = "修改密码")
    @GetMapping("/changePwd")
    public Result changePwd(@RequestParam("stuId")String stuId,
                            @RequestParam("usedPassword")String usedPassword,
                            @RequestParam("newPassword1")String newPassword1,
                            @RequestParam("newPassword2")String newPassword2){
        Student student = studentService.findOneStudentById(stuId);
        if(student == null){

            return Result.error().data("提示","用户名不存在,重新输入");
        }
        else{
            if(usedPassword.equals(student.getStuKey()) && newPassword1.equals(newPassword2)){
                studentService.changePassword(stuId, newPassword2);
                return Result.ok();
            }

            else
                return Result.error().data("提示","密码有误,重新输入!");

        }

    }

}
