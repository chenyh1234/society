package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;


@Component
public interface AdminLoginMapper extends BaseMapper<Admin> {

    @Select("select * from admin")
    ArrayList<Admin> findAllAdmin();

    @Select("select * from admin where adm_name =#{name}")
    Admin findOneAdminByName(@Param("name")  String name);

    @Select("select * from admin where adm_id =#{id}")
    Admin findOneAdminById(@Param("id") String id);

    @Insert("insert into admin(adm_id,adm_name,adm_key) values(#{id},#{name},#{pwd})")
    void registerAdmin(@Param("id")    String id,
                       @Param("name")  String name,
                       @Param("pwd")   String pwd);

    @Update("update admin set adm_key =#{pwd} where adm_id=#{id}")
    void changePassword(@Param("id")  String id,
                       @Param("pwd")  String pwd);

}
