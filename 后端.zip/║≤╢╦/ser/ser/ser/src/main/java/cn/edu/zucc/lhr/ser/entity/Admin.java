package cn.edu.zucc.lhr.ser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("admin")
public class Admin {
    @TableId
    private String adminId;
    private String adminKey;
    private String adminName;

//        public Admin(){
//
//    }
    public Admin(String adminId, String adminKey, String adminName) {
        this.adminId = adminId;
        this.adminName = adminName;
        this.adminKey = adminKey;
    }



//    public Admin(String adminId, String adminKey, String adminName){
//        this.adminId = adminId;
//        this.adminName = adminName;
//        this.adminKey = adminKey;
//    }
}
