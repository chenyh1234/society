package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Member;
import cn.edu.zucc.lhr.ser.entity.Notice;
import cn.edu.zucc.lhr.ser.entity.Society;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public interface MemberMapper extends BaseMapper<Member> {

    @Select("select * from member")
    ArrayList<Member> findAllMember();


    @Select("select * from member where mem_id =#{id}")
    Member findOneMemberById(@Param("id") String id);


    @Update("update member set mem_key =#{pwd} where mem_id=#{id}")
    void changePassword(@Param("id")  String id,
                       @Param("pwd")  String pwd);

    @Insert("insert into member(mem_id,mem_name,mem_key) values(#{id},#{name},#{pwd})")
    void registerMember(@Param("id") String id,
                       @Param("name")  String name,
                        @Param("pwd")  String pwd);


//    @Select("select e.mem_name " +
            @Select("select * " +
            "from president a,soc_of_pre b,society c,society_of_member d,member e " +
            "where a.pre_id = #{preId} and b.pre_id = a.pre_id and c.soc_id = b.soc_id and d.soc_id = c.soc_id and e.mem_id = d.mem_id " +
            "and e.mem_name like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Member> findAllMemberByPreId (@Param("preId")String preId,
                                             @Param("startid") Integer startid,
                                             @Param("pagesize") Integer pagesize,
                                             @Param("query") String query);
//    @Select("select count(e.mem_name) " +
            @Select("select count(*) " +
            "from president a,soc_of_pre b,society c,society_of_member d,member e " +
            "where a.pre_id = #{preId} and b.pre_id = a.pre_id and c.soc_id = b.soc_id and d.soc_id = c.soc_id and e.mem_id = d.mem_id " +
            "and e.mem_name like '%${query}%' ")
    Integer calculateTotalMemberNumber(@Param("preId")String preId,
                                       @Param("query")String query);

    @Update("update society set soc_member_count=soc_member_count-1 where soc_id =#{socId}")
    void UpdateSocMemberCount(@Param("socId")String socId);

    @Delete("delete  from society_of_member where soc_id = #{socId} and mem_id =#{memId} ;" )
    void DeleteSocietyBySocIdAndMemId(@Param("socId")String socId,
                                      @Param("memId")String memId);


//    @Select("select a.act_name,a.act_time,a.position,a.limit_count " +
    @Select("select * " +
            "from activity a,mem_of_act b " +
            "where  b.mem_id =#{memId} and a.act_id = b.act_id "+
            "and a.act_name like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Activity> findAllActivityByMemId(@Param("memId")String memId,
                                               @Param("startid") Integer startid,
                                               @Param("pagesize") Integer pagesize,
                                               @Param("query") String query);

    @Select("select count(*) " +
            "from activity a,mem_of_act b " +
            "where  b.mem_id =#{memId} and a.act_id = b.act_id "+
            "and a.act_name like '%${query}%'")
    Integer calculateTotalActivityNumber(String memId, String query);

    @Select("select *  " +
//    @Select("select a.soc_name,a.soc_introduction,a.soc_member_count  " +
            "from society a,member b,society_of_member c " +
            "where c.mem_id=b.mem_id and  a.soc_id= c.soc_id and b.mem_id=#{memId} " +
            "and a.soc_name like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Society> findSocietyByMemId(@Param("memId")String memId,
                                          @Param("startid") Integer startid,
                                          @Param("pagesize") Integer pagesize,
                                          @Param("query") String query);
    @Select("select count(*)  " +
//    @Select("select a.soc_name,a.soc_introduction,a.soc_member_count  " +
            "from society a,member b,society_of_member c " +
            "where c.mem_id=b.mem_id and  a.soc_id= c.soc_id and b.mem_id=#{memId} " +
            "and a.soc_name like '%${query}%'")
    Integer calculateTotalSocietyNumber(@Param("memId")String memId,
                                        @Param("query") String query);

    @Select("select * from member a,society_of_member b,society c,soc_of_pre d, president e, notice f " +
            "where a.mem_id = #{memId}  and b.mem_id = a.mem_id and c.soc_id = b.soc_id and d.soc_id = c.soc_id " +
            "and e.pre_id = d.pre_id and f.pre_id = e.pre_id" +
            " and f.not_content like '%${query}%' order BY  c.soc_name limit #{startid}, #{pagesize}")
    ArrayList<Notice> findAllNoticeDivideByMemId(@Param("memId")String memId,
                                                 @Param("startid") Integer startid,
                                                 @Param("pagesize") Integer pagesize,
                                                 @Param("query") String query);

    @Select("select count(*) from member a,society_of_member b,society c,soc_of_pre d, president e, notice f " +
            "where a.mem_id = #{memId}  and b.mem_id = a.mem_id and c.soc_id = b.soc_id and d.soc_id = c.soc_id " +
            "and e.pre_id = d.pre_id and f.pre_id = e.pre_id" +
            " and f.not_content like '%${query}%' ")
    Integer calculateTotalNoticeNumber(@Param("memId")String memId,@Param("query") String query);

    @Delete("delete from member where mem_id = #{memId}")
    void DeleteMemberByMemId(String memId);

}
