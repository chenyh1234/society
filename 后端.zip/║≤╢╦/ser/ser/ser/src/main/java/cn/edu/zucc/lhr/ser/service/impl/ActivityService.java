package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.mapper.ActivityMapper;
import cn.edu.zucc.lhr.ser.service.IActivityService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;


@Transactional
@Service
public class ActivityService extends ServiceImpl<ActivityMapper, Activity> implements IActivityService {

    @Autowired
    ActivityMapper activityMapper;

    @Override
    public ArrayList<Activity>  findAllActivityDivide(Integer startid, Integer pagesize, String query){
        return activityMapper.findAllActivityDivide(startid,pagesize,query);
    }

    @Override
    public ArrayList<Activity> findAllActivityDivideByStuId(String stuId, Integer startid, Integer pagesize, String query) {
        return activityMapper.findAllActivityDivideByStuId(stuId,startid,pagesize,query);
    }

    @Override
    public Integer calculateTotalActivityNumberByStuId(String stuId, String query) {
        return activityMapper.calculateTotalActivityNumberByStuId(stuId,query);
    }

    @Override
    public Integer calculateTotalActivityNumber(String query) {
        return activityMapper.calculateTotalActivityNumber(query);
    }

    @Override
    public Integer findSocIdByPreId(String preId) {
        return activityMapper.findSocIdByPreId(preId);
    }

    @Override
    public void addActivity(Integer socId, String actName, Date actTime, String position, Integer limitCount) {
        activityMapper.addActivity(socId,actName,actTime,position,limitCount);
    }

    @Override
    public void changeActivityByActId(Integer actId, String actName, Date actTime, String position, Integer limitCount){
        activityMapper.changeActivityByActId(actId,actName,actTime,position,limitCount);
    }

    @Override
    public void deleteStuInActivity(Integer actId) {
        activityMapper.deleteStuInActivity(actId);
    }

    @Override
    public void deleteMemOfAct(Integer actId) {
        activityMapper.deleteMemOfAct(actId);
    }

    @Override
    public void deleteActivityByActId(Integer actId) {
        activityMapper.deleteActivityByActId(actId);
    }

    @Override
    public Integer selectMaxActId() {
        return activityMapper.selectMaxActId();
    }

    @Override
    public void updateMemOfAct(Integer actId, String memId) {
        activityMapper.updateMemOfAct(actId,memId);
    }

    @Override
    public Activity findActivityByActId(String actId) {
        return activityMapper.findActivityByActId(actId);
    }


}
