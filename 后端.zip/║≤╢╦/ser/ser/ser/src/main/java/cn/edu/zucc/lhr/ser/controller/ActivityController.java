package cn.edu.zucc.lhr.ser.controller;

import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.service.IActivityService;
import cn.edu.zucc.lhr.ser.service.INoticeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

@Api(tags = "活动模块")
@RestController
@RequestMapping("/Activity")
public class ActivityController {

    @Resource
    @Autowired
    INoticeService noticeService;
    @Resource
    @Autowired
    IActivityService activityService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    @ApiOperation(value = "分页列出所有活动")
    @GetMapping("/findAllActivityDivide")
    public Result queryAllActivityDivide(@RequestParam("pagesize")Integer pagesize,
                                         @RequestParam("pagenum")Integer pagenum,
                                         @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
//        Integer total = (getSocietyTotalNumber()-1)/count+1;
        ArrayList<Activity> records = activityService.findAllActivityDivide(startid,pagesize,query);
        Integer total = totalNumber(query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }
    @ApiOperation(value = "计算所有活动分页显示结果")
    @GetMapping("/calculateTotalActivityNumber")
    public Integer totalNumber(@RequestParam("query") String query){
        return activityService.calculateTotalActivityNumber(query);

    }
    @ApiOperation(value = "添加活动")
        @GetMapping("/addActivityByPreId")
    public Result addActivityByPreId(@RequestParam("preId")String preId,
                                     @RequestParam("actName")String actName,
                                     @RequestParam("actTime") Date actTime,
                                     @RequestParam("position")String position,
                                     @RequestParam("limitCount")Integer limitCount){

        Integer socId = activityService.findSocIdByPreId(preId);
        activityService.addActivity(socId,actName,actTime,position,limitCount);
        Integer actId = activityService.selectMaxActId();
        ArrayList<String> memIdList= noticeService.findAllMemIdByPreId(preId);
        for(Integer i = 0; i<memIdList.size(); i++){
            String memId = memIdList.get(i);
            activityService.updateMemOfAct(actId,memId);
        }

        return Result.ok().data("提示","添加成功");
    }

    @ApiOperation(value = "根据活动id找活动对象")
    @GetMapping("/findActivityByActId")
    public Result findActivityByActId(@RequestParam("actId")String actId)
    {
        Activity activity = activityService.findActivityByActId(actId);
        return Result.ok().data("activity",activity);
    }

    @ApiOperation(value = "修改活动")
    @GetMapping("/changeActivityByActId")
    public Result changeActivityByActId(@RequestParam("actId")Integer actId,
                                        @RequestParam("actName")String actName,
                                        @RequestParam("actTime") Date actTime,
                                        @RequestParam("position")String position,
                                        @RequestParam("limitCount")Integer limitCount)
    {
        activityService.changeActivityByActId(actId,actName,actTime,position,limitCount);
        return Result.ok().data("提示","修改成功");
    }

    @ApiOperation(value = "结束活动")
    @GetMapping("/deleteActivityByActId")
    public Result deleteActivityByActId(@RequestParam("actId")Integer actId){
        activityService.deleteStuInActivity(actId);
        activityService.deleteMemOfAct(actId);
        activityService.deleteActivityByActId(actId);
        return  Result.ok().data("提示","删除成功");
    }

}
