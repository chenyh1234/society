package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Admin;
import cn.edu.zucc.lhr.ser.mapper.AdminLoginMapper;
import cn.edu.zucc.lhr.ser.service.IAdminLoginService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


@Transactional
@Service
public class AdminLoginService extends ServiceImpl<AdminLoginMapper, Admin> implements IAdminLoginService {

    @Autowired
    AdminLoginMapper adminLoginMapper;

    @Override
    public Admin findOneAdminById(String id){return adminLoginMapper.findOneAdminById(id);}

    @Override
    public ArrayList<Admin> findAllAdmin() {
        return adminLoginMapper.findAllAdmin();
    }

    @Override
    public Admin findOneAdminByName(String name) {
        return adminLoginMapper.findOneAdminByName(name);
    }

    @Override
    public void registerAdmin(String id,String name, String pwd) {
       adminLoginMapper.registerAdmin(id,name, pwd);
    }

    @Override
    public void changePassword(String id, String pwd) {
        adminLoginMapper.changePassword(id, pwd);
    }


}
