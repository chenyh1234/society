package cn.edu.zucc.lhr.ser.controller;

import cn.edu.zucc.lhr.ser.entity.Society;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.service.ISocietyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;

@Api(tags = "社团模块")
@RestController
@RequestMapping("/Society")
public class SocietyController {

    @Resource
    @Autowired
    ISocietyService societyService;


    @ApiOperation(value = "获取所有社团分页显示")
    @GetMapping("/findAllSociety")
    //pagesize是页数,每页的数量，pagenum表示要看第几页
    public Result queryAllSociety(@RequestParam("pagesize")Integer pagesize,
                                  @RequestParam("pagenum")Integer pagenum,
                                  @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        Integer total = totalNumber(query);
//        Integer total = (getSocietyTotalNumber()-1)/count+1;
        ArrayList<Society> records = societyService.findAllSociety(startid,pagesize,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有社团分页显示结果")
    @GetMapping("/calculateTotalNumber")
    public Integer totalNumber(@RequestParam("query") String query){
        return societyService.calculateTotalNumber(query);

    }

    @ApiOperation(value = "建立新社团")
    @GetMapping("/registerSociety")
    public Result registerSociety(@RequestParam(value = "socMemberCount", required = true,defaultValue = "0")  Integer socMemberCount,
                                  @RequestParam(value = "socAlive", required = true,defaultValue = "1") Integer socAlive,
                                  @RequestParam("socIntroduction")  String socIntroduction,
                                  @RequestParam("socName")  String socName){

        societyService.registerSociety(socMemberCount,socAlive,socIntroduction,socName);
        return Result.ok();

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }



    @ApiOperation(value = "根据id删除社团")
    @GetMapping("/removeSocietyById")
    public Result removeSocietyById(@RequestParam("socId")  Integer id){
        Society society = queryOneSocietyById(id);
        if(society != null){
            societyService.DeleteSocietyById(id);
            return Result.ok();
        }
        else{
            return Result.error().data("提示", "删除失败");
        }
    }
    //返回前端用
    @ApiOperation(value = "通过社团id获取社团")
    @GetMapping("/findOneSocietyBySocId")
    public Result queryOneSocietyBySocId(@RequestParam("socId")Integer id){
        Society society =societyService.findOneSocietyById(id);
        return Result.ok().data("society",society);
    }

    @ApiOperation(value = "通过社长id获取社团")
    @GetMapping("/findOneSocietyByPreId")
    public Result queryOneSocietyByPreId(@RequestParam("preId")String preId){
        Society society =societyService.findOneSocietyByPreId(preId);
        return Result.ok().data("society",society);
    }

    @ApiOperation(value = "获取社团总数")
    @GetMapping("/getSocietyTotalNumber")
    public Integer getSocietyTotalNumber(){
        return societyService.getSocietyTotalNumber();
    }




    @ApiOperation(value = "通过id获取社团")
    @GetMapping("/findOneSocietyById")
    public Society queryOneSocietyById(Integer id){
        return societyService.findOneSocietyById(id);
    }





}
