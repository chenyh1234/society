package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Application;
import cn.edu.zucc.lhr.ser.entity.President;
import cn.edu.zucc.lhr.ser.mapper.PresidentMapper;
import cn.edu.zucc.lhr.ser.service.IPresidentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


@Transactional
@Service
public class PresidentService extends ServiceImpl<PresidentMapper, President> implements IPresidentService {

    @Autowired
    PresidentMapper presidentMapper;
    @Override
    public President findOnePresidentById(String id){return presidentMapper.findOnePresidentById(id);}

    @Override
    public ArrayList<President> findAllPresident() {
        return presidentMapper.findAllPresident();
    }

    @Override
    public void changePassword(String id, String pwd) {
        presidentMapper.changePassword(id, pwd);
    }

    @Override
    public void registerPresident(String id,String name, String pwd) {
        presidentMapper.registerPresident(id,name, pwd);
    }


    @Override
    public ArrayList<Application> findApplicationByPreId(String preId, Integer startid, Integer pagesize, String query) {
        return presidentMapper.findApplicationByPreId(preId,startid,pagesize,query);
    }

    @Override
    public Integer calculateTotalApplicationNumberByPreId(String preId, String query) {
        return presidentMapper.calculateTotalApplicationNumberByPreId(preId,query);
    }

    @Override
    public Integer getSocIdFromSocOfPre(String preId) {
        return presidentMapper.getSocIdFromSocOfPre(preId);
    }

//    @Override
//    public void deleteSocOfPre(String preId, Integer socId) {
//        presidentMapper.deleteSocOfPre(preId,socId);
//    }

    @Override
    public void deleteNoticeOfPre(String preId) {
        presidentMapper.deleteNoticeOfPre(preId);
    }

    @Override
    public void deleteNotForMem(String preId) {
        presidentMapper.deleteNotForMem(preId);
    }

    @Override
    public void deletePresident(String preId) {
        presidentMapper.deletePresident(preId);
    }

    @Override
    public void updateSocietyNumber(Integer appId) {
        presidentMapper.updateSocietyNumber(appId);
    }

    @Override
    public void insertSocOfMem(String memId, Integer socId) {
        presidentMapper.insertSocOfMem(memId,socId);
    }

    @Override
    public void updateAppStatusYes(Integer appId) {
        presidentMapper.updateAppStatusYes(appId);
    }

    @Override
    public void updateAppStatusNo(Integer appId) {
        presidentMapper.updateAppStatusNo(appId);
    }

    @Override
    public ArrayList<Activity> findAllActivityDivideByPreId(String preId, Integer startid, Integer pagesize, String query) {
        return presidentMapper.findAllActivityDivideByPreId(preId,startid,pagesize,query);
    }

    @Override
    public Integer calculateTotalActivityNumberByPreId(String preId, String query) {
        return presidentMapper.calculateTotalActivityNumberByPreId(preId,query);
    }

    @Override
    public void changeSocOfPre(String preId, Integer socId) {
         presidentMapper.changeSocOfPre(preId,socId);
    }

    @Override
    public void updateSocOfPre(String stuId, Integer socId) {
        presidentMapper.updateSocOfPre(stuId,socId);
    }

    @Override
    public String findPreIdBySocId(Integer socId) {
        return presidentMapper.findPreIdBySocId(socId);
    }

    @Override
    public void preDeleteMemOfAct(String memId) {
        presidentMapper.preDeleteMemOfAct(memId);
    }

    @Override
    public void preDeleteNotForMem(String memId) {
        presidentMapper.preDeleteNotForMem(memId);
    }

    @Override
    public void preDeleteSocOfMember(String memId) {
        presidentMapper.preDeleteSocOfMember(memId);
    }

    @Override
    public void preKickMember(String memId) {
        presidentMapper.preKickMember(memId);
    }

}
