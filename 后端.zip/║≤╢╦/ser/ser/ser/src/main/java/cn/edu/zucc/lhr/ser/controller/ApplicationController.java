package cn.edu.zucc.lhr.ser.controller;

import cn.edu.zucc.lhr.ser.entity.Application;
import cn.edu.zucc.lhr.ser.service.IApplicationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Api(tags = "申请模块")
@RestController
@RequestMapping("/Application")
public class ApplicationController {

    @Resource
    @Autowired
    IApplicationService applicationService;

    @ApiOperation(value = "通过id获取申请")
    @GetMapping("/queryOneApplicationById")
    public Application queryOneApplicationById(@RequestParam("appId") Integer appId){
        return applicationService.findOneApplicationById(appId);
    }
//    @ApiOperation(value = "分页列出所有活动")
//    @GetMapping("/findAllApplicationDivide")
//    public Result queryAllActivityDivide(@RequestParam("pagesize")Integer pagesize,
//                                  @RequestParam("pagenum")Integer pagenum,
//                                  @RequestParam("query") String query){
//        Integer startid;
//        startid=pagesize*(pagenum-1);
//        ArrayList<Activity> records = activityService.findAllActivityDivide(startid,pagesize,query);
//        Integer total = records.size();
//        return Result.ok().data("total",total).data("records",records);
//
//    }



}
