package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Application;
import cn.edu.zucc.lhr.ser.entity.President;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public interface PresidentMapper extends BaseMapper<President> {

    @Select("select * from president")
    ArrayList<President> findAllPresident();


    @Select("select * from president where pre_id =#{id}")
    President findOnePresidentById(@Param("id") String id);


    @Update("update president set pre_key =#{pwd} where pre_id=#{id}")
    void changePassword(@Param("id")  String id,
                       @Param("pwd")  String pwd);

    @Insert("insert into president(pre_id,pre_name,pre_key) values(#{id},#{name},#{pwd})")
    void registerPresident(@Param("id") String id,
                       @Param("name")  String name,
                       @Param("pwd")  String pwd);


    @Select("    select * from president a,soc_of_pre b, society c, application d " +
            "where a.pre_id = #{preId} and b.pre_id = a.pre_id and c.soc_id = b.soc_id " +
            "and d.soc_id = c.soc_id " +
            "and d.app_status like '%${query}%' order by d.app_status desc limit #{startid}, #{pagesize} ")
    ArrayList<Application> findApplicationByPreId(@Param("preId")String preId,
                                                  @Param("startid") Integer startid,
                                                  @Param("pagesize") Integer pagesize,
                                                  @Param("query") String query);

    @Select("    select count(*) from president a,soc_of_pre b, society c, application d " +
            "where a.pre_id = #{preId} and b.pre_id = a.pre_id and c.soc_id = b.soc_id " +
            "and d.soc_id = c.soc_id " +
            "and d.app_status like '%${query}%' ")
    Integer calculateTotalApplicationNumberByPreId(@Param("preId")String preId,
                                                   @Param("query") String query);
    @Select("select soc_id from soc_of_pre where pre_id = #{preId}")
    Integer getSocIdFromSocOfPre(@Param("preId")String preId);

//    @Delete("delete from soc_of_pre where pre_id = #{preId} and soc_id = #{socId}")
//    void deleteSocOfPre(@Param("preId")String preId,
//                        @Param("socId")Integer socId);

    @Delete("delete from notice where pre_id = #{preId} ")
    void deleteNoticeOfPre(@Param("preId")String preId);

    @Delete("delete from not_for_mem where not_id in  " +
            "(select not_id from notice where pre_id= #{preId} )  ")
    void deleteNotForMem(@Param("preId")String preId);

    @Delete("delete from president where pre_id = #{preId} ")
    void deletePresident(@Param("preId")String preId);

    @Update("update society set soc_member_count =soc_member_count +1 " +
            "where soc_id in(select soc_id from application where app_id = #{appId}) " )
    void updateSocietyNumber(@Param("appId") Integer appId);

    @Insert("insert into society_of_member(mem_id,soc_id) values(#{memId},#{socId})")
    void insertSocOfMem(@Param("memId")String memId,
                        @Param("socId")Integer socId);


    @Update("update application set app_status = \"已通过\" where app_id =#{appId} " )
    void updateAppStatusYes(@Param("appId")Integer appId);

    @Update("update application set app_status = \"未通过\" where app_id =#{appId} " )
    void updateAppStatusNo(@Param("appId")Integer appId);


    @Select("select * from president a,soc_of_pre b,activity c  " +
            "where b.pre_id =a.pre_id and a.pre_id =#{preId} and c.soc_id = b.soc_id" +
            " and c.act_name like '%${query}%'  limit #{startid}, #{pagesize}")
    ArrayList<Activity> findAllActivityDivideByPreId(@Param("preId")String preId,
                                                     @Param("startid") Integer startid,
                                                     @Param("pagesize") Integer pagesize,
                                                     @Param("query") String query);

    @Select("select count(*) from president a,soc_of_pre b,activity c  " +
            "where b.pre_id =a.pre_id and a.pre_id =#{preId} and c.soc_id = b.soc_id" +
            " and c.act_name like '%${query}%' ")
    Integer calculateTotalActivityNumberByPreId(@Param("preId")String preId,
                                                @Param("query") String query);

    @Update("update soc_of_pre set pre_id=#{preId} where soc_id=#{socId}")
    void changeSocOfPre(@Param("preId")String preId,
                        @Param("socId") Integer socId);

    @Insert("insert into soc_of_pre (soc_id,pre_id) values(#{socId},#{stuId})")
    void updateSocOfPre(@Param("stuId")String stuId,
                        @Param("socId") Integer socId);

    @Select("select pre_id from soc_of_pre where soc_id = #{socId}")
    String findPreIdBySocId(@Param("socId") Integer socId);

    @Delete("delete from mem_of_act where mem_id=#{memId}")
    void preDeleteMemOfAct(@Param("memId") String memId);

    @Delete("delete from not_for_mem where mem_id=#{memId}")
    void preDeleteNotForMem(@Param("memId") String memId);

    @Delete("delete from society_of_member where mem_id=#{memId}")
    void preDeleteSocOfMember(@Param("memId") String memId);

    @Delete("delete from member where mem_id=#{memId}")
    void preKickMember(@Param("memId") String memId);
}
