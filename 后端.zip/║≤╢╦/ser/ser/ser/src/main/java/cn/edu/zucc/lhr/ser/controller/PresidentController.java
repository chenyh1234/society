package cn.edu.zucc.lhr.ser.controller;


import cn.edu.zucc.lhr.ser.entity.*;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.service.IApplicationService;
import cn.edu.zucc.lhr.ser.service.IMemberService;
import cn.edu.zucc.lhr.ser.service.IPresidentService;
import cn.edu.zucc.lhr.ser.service.IStudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;

@Api(tags = "社长模块")
@RestController
@RequestMapping("/President")
public class PresidentController {

    @Resource
    @Autowired
    IApplicationService applicationService;

    @Resource
    @Autowired
    IStudentService studentService;

    @Resource
    @Autowired
    IMemberService memberService;
    @Resource
    @Autowired
    IPresidentService presidentService;

    @ApiOperation(value = "获取所有社长")
    @GetMapping("/findAllPresident")
    public ArrayList<President> queryAllAdmin(){
        return presidentService.findAllPresident();
    }

    @ApiOperation(value = "通过id获取社长")
    @GetMapping("/queryOnePresidentById")
    public President queryOnePresidentById(String id){
        return presidentService.findOnePresidentById(id);
    }

    @ApiOperation(value = "通过社长id分页查询显示所有社团申请")
    @GetMapping("/findApplicationByPreId")
    public Result queryApplicationByPreId(@RequestParam("preId")String preId,
                                          @RequestParam("pagesize")Integer pagesize,
                                          @RequestParam("pagenum")Integer pagenum,
                                          @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        Integer total = totalApplicationNumberByPreId(preId,query);
        ArrayList<Application> records =presidentService.findApplicationByPreId(preId,startid,pagesize,query);
        return Result.ok().data("total",total).data("records",records);
    }

    @ApiOperation(value = "计算所有申请分页显示结果数量")
    @GetMapping("/calculateTotalApplicationNumberByPreId")
    public Integer totalApplicationNumberByPreId(  @RequestParam("preId")String preId,
                                                @RequestParam("query") String query){
        return presidentService.calculateTotalApplicationNumberByPreId(preId,query);

    }

    @ApiOperation(value = "转让社长")
    @GetMapping("/changePresident")
    public Result changePresident(  @RequestParam("preId")String preId,
                                     @RequestParam("memId")String memId
                                     ){
        Member member = memberService.findOneMemberById(memId);
//        President president = presidentService.findOnePresidentById(preId);
        Integer socId= presidentService.getSocIdFromSocOfPre(preId);
        presidentService.deleteNotForMem(preId);
        presidentService.deleteNoticeOfPre(preId);
//        insertStudent(preId,president.getPreName(),president.getPreKey());
        insertPresident(memId,member.getMemName(),member.getMemKey());
        presidentService.changeSocOfPre(memId,socId);
        presidentService.deletePresident(preId);
        return Result.ok().data("提示","转让成功");
    }

    @ApiOperation(value = "同意申请")
    @GetMapping("/consentApplication")
    public Result consentApplication(@RequestParam("appId")Integer appId){
        Application application = applicationService.findOneApplicationById(appId);
        if(application.getAppStatus().equals("等待审核")) {
            presidentService.updateSocietyNumber(appId);
            Student student = studentService.findStudentByAppId(appId);
            insertMember(student.getStuId(), student.getStuName(), student.getStuKey());
            Integer socId = application.getSocId();
            presidentService.insertSocOfMem(student.getStuId(), socId);
            presidentService.updateAppStatusYes(appId);
            return Result.ok().data("提示","申请通过");
        }
        else
//        insertStudent(preId,president.getPreName(),president.getPreKey());
            return Result.error().data("提示","无法审核");
}

    @ApiOperation(value = "拒绝申请")
    @GetMapping("/refuseApplication")
    public Result refuseApplication(@RequestParam("appId")Integer appId) {
        Application application = applicationService.findOneApplicationById(appId);
        if(application.getAppStatus().equals("等待审核")){
            presidentService.updateAppStatusNo(appId);
        return Result.ok().data("提示","申请已拒绝");
        }
        else
//        insertStudent(preId,president.getPreName(),president.getPreKey());
            return Result.error().data("提示","无法审核");

    }

    @ApiOperation(value = "通过社长id分页列出本社团所有活动")
    @GetMapping("/findAllActivityDivideByPreId")
    public Result queryAllActivityDivideByPreId(@RequestParam("preId")String preId,
                                                @RequestParam("pagesize")Integer pagesize,
                                                @RequestParam("pagenum")Integer pagenum,
                                                @RequestParam("query") String query){
        Integer startid;
        startid=pagesize*(pagenum-1);
        ArrayList<Activity> records = presidentService.findAllActivityDivideByPreId(preId,startid,pagesize,query);
        Integer total = totalActivityNumberByPreId(preId,query);
        return Result.ok().data("total",total).data("records",records);

        //limit第一个参数是下标从第几个开始（0为第一个），第二个是输出几个
    }

    @ApiOperation(value = "计算所有申请分页显示结果数量")
    @GetMapping("/calculateTotalActivityNumberByPreId")
    public Integer totalActivityNumberByPreId(  @RequestParam("preId")String preId,
                                                @RequestParam("query") String query){
        return presidentService.calculateTotalActivityNumberByPreId(preId,query);

    }





    public void insertMember( String id, String name, String pwd) {
        Member member = memberService.findOneMemberById(id);
        if (member == null) {
            memberService.registerMember(id, name, pwd);
        } else {
        }

    }

    public void insertStudent( String id, String name, String pwd) {
        Student student = studentService.findOneStudentById(id);
        if (student == null) {
            studentService.registerStudent(id, name, pwd);
        } else {
        }

    }

    public void insertPresident( String id, String name, String pwd) {
        President onePresident = queryOnePresidentById(id);
        if (onePresident == null) {
            presidentService.registerPresident(id, name, pwd);
        } else {
        }

    }

    @ApiOperation(value = "修改密码")
    @GetMapping("/changePwd")
    public Result changePwd(@RequestParam("preId")String preId,
                            @RequestParam("usedPassword")String usedPassword,
                            @RequestParam("newPassword1")String newPassword1,
                            @RequestParam("newPassword2")String newPassword2){
        President president = queryOnePresidentById(preId);
        if(president == null){

            return Result.error().data("提示","用户名不存在,重新输入");
        }
        else{
            if(usedPassword.equals(president.getPreKey()) && newPassword1.equals(newPassword2)){
                presidentService.changePassword(preId, newPassword2);
                return Result.ok();
            }

            else
                return Result.error().data("提示","密码有误,重新输入!");

        }

    }



}
