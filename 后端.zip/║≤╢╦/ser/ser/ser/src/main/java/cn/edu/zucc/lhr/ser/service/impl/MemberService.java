package cn.edu.zucc.lhr.ser.service.impl;



import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Member;
import cn.edu.zucc.lhr.ser.entity.Notice;
import cn.edu.zucc.lhr.ser.entity.Society;
import cn.edu.zucc.lhr.ser.mapper.MemberMapper;
import cn.edu.zucc.lhr.ser.service.IMemberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


@Transactional
@Service
public class MemberService extends ServiceImpl<MemberMapper, Member> implements IMemberService {

    @Autowired
    MemberMapper memberMapper;
    @Override
    public Member findOneMemberById(String id){return memberMapper.findOneMemberById(id);}

    @Override
    public ArrayList<Member> findAllMember() {
        return memberMapper.findAllMember();
    }

    @Override
    public void changePassword(String id, String pwd) {
        memberMapper.changePassword(id, pwd);
    }

    @Override
    public void registerMember(String id,String name, String pwd) {
        memberMapper.registerMember(id,name, pwd);
    }

    @Override
    public ArrayList<Member> findAllMemberByPreId(String preId, Integer startid, Integer pagesize, String query) {
        return memberMapper.findAllMemberByPreId(preId,startid,pagesize,query);
    }

    @Override
    public void DeleteSocietyBySocIdAndMemId(String socId, String memId) {
        memberMapper.DeleteSocietyBySocIdAndMemId(socId,memId);
    }

    @Override
    public void UpdateSocMemberCount(String socId) {
        memberMapper.UpdateSocMemberCount(socId);
    }

    @Override
    public ArrayList<Activity> findAllActivityByMemId(String memId, Integer startid, Integer pagesize, String query) {
        return memberMapper.findAllActivityByMemId(memId,startid,pagesize,query);
    }
    @Override
    public ArrayList<Society> findSocietyByMemId(String memId, Integer startid, Integer pagesize, String query) {
        return memberMapper.findSocietyByMemId(memId,startid,pagesize,query);
    }

    @Override
    public ArrayList<Notice> findAllNoticeDivideByMemId(String memId, Integer startid, Integer pagesize, String query) {
        return memberMapper.findAllNoticeDivideByMemId(memId,startid,pagesize,query);
    }

    @Override
    public Integer calculateTotalMemberNumber(String preId,String query) {
        return memberMapper.calculateTotalMemberNumber(preId,query);
    }

    @Override
    public Integer calculateTotalActivityNumber(String memId, String query) {
        return memberMapper.calculateTotalActivityNumber(memId,query);
    }

    @Override
    public Integer calculateTotalSocietyNumber(String memId, String query) {
        return memberMapper.calculateTotalSocietyNumber(memId,query);
    }

    @Override
    public Integer calculateTotalNoticeNumber(String memId, String query) {
        return memberMapper.calculateTotalNoticeNumber(memId,query);
    }

    @Override
    public void DeleteMemberByMemId(String memId) {
        memberMapper.DeleteMemberByMemId(memId);
    }
}
