package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Activity;
//import cn.edu.shu.xj.ser.entity.Member
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;
import java.util.Date;

public interface IActivityService extends IService<Activity> {


    ArrayList<Activity> findAllActivityDivide(Integer startid, Integer pagesize, String query);

    ArrayList<Activity> findAllActivityDivideByStuId(String stuId, Integer startid, Integer pagesize, String query);

    Integer calculateTotalActivityNumberByStuId(String stuId, String query);

    Integer calculateTotalActivityNumber(String query);

    Integer findSocIdByPreId(String preId);

    void addActivity(Integer socId, String actName, Date actTime, String position, Integer limitCount);

    Activity findActivityByActId(String actId);

    void changeActivityByActId(Integer actId, String actName, Date actTime, String position, Integer limitCount);

    void deleteStuInActivity(Integer actId);

    void deleteMemOfAct(Integer actId);

    void deleteActivityByActId(Integer actId);

    Integer selectMaxActId();

    void updateMemOfAct(Integer actId, String memId);

//    Activity findActivityByPreId(String preId);
}
