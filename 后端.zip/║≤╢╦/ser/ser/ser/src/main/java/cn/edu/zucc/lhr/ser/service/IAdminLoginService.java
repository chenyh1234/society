package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;

public interface IAdminLoginService extends IService<Admin> {

    ArrayList<Admin> findAllAdmin();

    Admin findOneAdminByName(String name);

    void registerAdmin(String id,String name, String pwd);

    void changePassword(String id, String pwd);

    Admin findOneAdminById(String id);

}
