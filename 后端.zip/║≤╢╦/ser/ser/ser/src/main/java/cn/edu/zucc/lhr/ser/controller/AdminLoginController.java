package cn.edu.zucc.lhr.ser.controller;

import cn.edu.zucc.lhr.ser.entity.Member;
import cn.edu.zucc.lhr.ser.entity.President;
import cn.edu.zucc.lhr.ser.entity.Student;
import cn.edu.zucc.lhr.ser.response.Result;
import cn.edu.zucc.lhr.ser.config.Token;
import cn.edu.zucc.lhr.ser.entity.Admin;
import cn.edu.zucc.lhr.ser.service.IAdminLoginService;
import cn.edu.zucc.lhr.ser.service.IMemberService;
import cn.edu.zucc.lhr.ser.service.IPresidentService;
import cn.edu.zucc.lhr.ser.service.IStudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;

@Api(tags = "登陆模块")
@RestController
@RequestMapping("/AdminLogin")
public class AdminLoginController{

    @Resource
    @Autowired
    IAdminLoginService adminLoginService;
    @Resource
    @Autowired
    IStudentService studentService;
    @Resource
    @Autowired
    IMemberService memberService;

    @Resource
    @Autowired
    IPresidentService presidentService;

    @ApiOperation(value = "获取所有管理员")
    @GetMapping("/findAllAdmin")
    public ArrayList<Admin> queryAllAdmin(){
        return adminLoginService.findAllAdmin();
    }

    @ApiOperation(value = "通过名字获取管理员")
    @GetMapping("/findOneAdminByName")
    public Admin queryOneAdminByName(String name){
         return adminLoginService.findOneAdminByName(name);
    }

    @ApiOperation(value = "通过id获取管理员")
    @GetMapping("/findOneAdminById")
    public Admin queryOneAdminById(String id){
        return adminLoginService.findOneAdminById(id);
    }

    @ApiOperation(value = "通过id获取学生")
    @GetMapping("/findOneStudentById")
    public Student queryOneStudentById(String id){
        return studentService.findOneStudentById(id);
    }

    @ApiOperation(value = "通过id获取成员")
    @GetMapping("/findOneMemberById")
    public Member queryOneMemberById(String id){
        return memberService.findOneMemberById(id);
    }

    @ApiOperation(value = "通过id获取社长")
    @GetMapping("/findOnePresidentById")
    public President queryOnePresidentById(String id){
        return presidentService.findOnePresidentById(id);
    }


    @ApiOperation(value = "登陆")
    @GetMapping("/login")
    public Result login(@RequestParam("identity") String identity,
                        @RequestParam("id") String id,
                        @RequestParam("pwd") String pwd){
        if(identity.equals("admin")){
            //Admin oneAdmin2 = queryOneAdminById(id);
            Admin oneAdmin2 =adminLoginService.findOneAdminById(id);
            String encryption = Token.encryption(id,"pwd");

            if(oneAdmin2 == null){
                return Result.error().data("提示","用户名不存在");
            }
            else if(oneAdmin2.getAdminKey().equals(pwd)){
                return Result.ok().data("oneAdmin",oneAdmin2).data("token",encryption);
            }

            else if(!pwd.equals(oneAdmin2.getAdminKey())) {
                return Result.error().data("提示", "密码错误");
            }
            else
                return Result.error().data("提示","ERROR!");
        }
        else if(identity.equals("student")){

            Student oneStudent = queryOneStudentById(id);
            String encryption = Token.encryption(id,"pwd");

            if(oneStudent == null){
                return Result.error().data("提示","用户名不存在");
            }
            else if(oneStudent.getStuKey().equals(pwd)){
                return Result.ok().data("oneStudent",oneStudent).data("token",encryption);
            }

            else if(!pwd.equals(oneStudent.getStuKey())) {
                return Result.error().data("提示", "密码错误");
            }
            else
                return Result.error().data("提示","ERROR!");
        }
        else if(identity.equals("member")){
            Member oneMember = queryOneMemberById(id);
            String encryption = Token.encryption(id,"pwd");

            if(oneMember == null){
                return Result.error().data("提示","用户名不存在");
            }
            else if(oneMember.getMemKey().equals(pwd)){
                return Result.ok().data("oneMember",oneMember).data("token",encryption);
            }

            else if(!pwd.equals(oneMember.getMemKey())) {
                return Result.error().data("提示", "密码错误");
            }
            else
                return Result.error().data("提示","ERROR!");
        }
        else if(identity.equals("president"))
        {
            President onePresident = queryOnePresidentById(id);
            String encryption = Token.encryption(id,"pwd");

            if(onePresident == null){
                return Result.error().data("提示","用户名不存在");
            }
            else if(onePresident.getPreKey().equals(pwd)){
                return Result.ok().data("onePresident",onePresident).data("token",encryption);
            }

            else if(!pwd.equals(onePresident.getPreKey())) {
                return Result.error().data("提示", "密码错误");
            }
            else
                return Result.error().data("提示","ERROR!");
        }
        else
            return Result.error().data("提示","不存在该身份!");
    }

    @ApiOperation(value = "注册")
    @GetMapping("/register")
    public Result insert(@RequestParam("identity") String identity,
                              @RequestParam("id") String id,
                              @RequestParam("name") String name,
                              @RequestParam("pwd") String pwd){
        if(identity.equals("admin")) {

            Admin oneAdmin = queryOneAdminById(id);
            if (oneAdmin != null) {
                return Result.error().data("提示", "用户已经存在!");
            } else {
                adminLoginService.registerAdmin(id, name, pwd);
                return Result.ok();
            }
        }
        else if(identity.equals("student")) {

            Student oneStudent = queryOneStudentById(id);
            if (oneStudent != null) {
                return Result.error().data("提示", "用户已经存在!");
            } else {
                studentService.registerStudent(id, name, pwd);
                return Result.ok();
            }
        }
        else if(identity.equals("member")) {

            Member oneMember = queryOneMemberById(id);
            if (oneMember != null) {
                return Result.error().data("提示", "用户已经存在!");
            } else {
                memberService.registerMember(id, name, pwd);
                return Result.ok();
            }
        }
        else if(identity.equals("president")) {

            President onePresident = queryOnePresidentById(id);
            if (onePresident != null) {
                return Result.error().data("提示", "用户已经存在!");
            } else {
                presidentService.registerPresident(id, name, pwd);
                return Result.ok();
            }
        }
        else
            return Result.error().data("提示","不存在该身份!");
    }
    @ApiOperation(value = "任命社长")
    @GetMapping("/choosePresident")
    public Result choosePresident(@RequestParam("socId") Integer socId,
                                  @RequestParam("stuId") String stuId
//                                  @RequestParam("stuName") String stuName,
//                                  @RequestParam("stuPwd") String stuPwd
    ){
        President president = queryOnePresidentById(stuId);
        if (president != null) {
            return Result.error().data("提示", "账号已经存在!");
        } else {
            Student student1 = studentService.findOneStudentById(stuId);
            String preId = presidentService.findPreIdBySocId(socId);
            if(preId != null)
                return Result.ok().data("提示", "已存在社长");
           else
               {presidentService.registerPresident(stuId, student1.getStuName(), student1.getStuKey());
                presidentService.updateSocOfPre(stuId, socId);
                return Result.ok().data("提示", "任命成功");
            }
        }

    }

    @ApiOperation(value = "社长踢出成员")
    @GetMapping("/preKickMember")
    public Result preKickMember(@RequestParam("memId") String memId){
        presidentService.preDeleteMemOfAct(memId);
        presidentService.preDeleteNotForMem(memId);
        presidentService.preDeleteSocOfMember(memId);
        presidentService.preKickMember(memId);
        return Result.ok().data("提示","踢出成功");
    }

//    @ApiOperation(value = "停用社团")
//    @GetMapping("/forbidSociety")
//    public Result forbidSociety(@RequestParam("socId") Integer socId){
//        presidentService.forbidSociety(socId);
//    }


    @ApiOperation(value = "修改密码")
    @GetMapping("/changePwd")
    public Result changePwd(@RequestParam("id")String id,
                            @RequestParam("usedPassword")String usedPassword,
                            @RequestParam("newPassword1")String newPassword1,
                            @RequestParam("newPassword2")String newPassword2)

    {
        Admin oneAdmin = queryOneAdminById(id);
        if(oneAdmin == null){

            return Result.error().data("提示","用户名不存在,重新输入");
        }
        else{
            if(usedPassword.equals(oneAdmin.getAdminKey()) && newPassword1.equals(newPassword2)){
                adminLoginService.changePassword(id, newPassword2);
                return Result.ok();
            }

            else
                return Result.error().data("提示","密码有误,重新输入!");

        }

    }

//    @ApiOperation(value = "修改用户名")
//    @GetMapping("/changeName")
//    public String changePwd(Integer id, String pwd){
//        Admin oneAdmin = queryOneAdminById(id);
//        if(oneAdmin == null){
//            return "用户名不存在,重新输入";
//        }
//        else{
//            adminLoginService.changePassword(name, pwd);
//            return "修改成功";
//        }
//    }

}
