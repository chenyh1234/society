package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Application;
import com.baomidou.mybatisplus.extension.service.IService;

public interface IApplicationService extends IService<Application> {

    Application findOneApplicationById(Integer id);


//    ArrayList<Application> findAllActivityDivide(Integer startid, Integer pagesize, String query);
}
