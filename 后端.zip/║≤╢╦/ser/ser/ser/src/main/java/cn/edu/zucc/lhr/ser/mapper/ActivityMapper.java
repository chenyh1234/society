package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Activity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;

@Component
public interface ActivityMapper extends BaseMapper<Activity> {



    @Select("select * from activity "+
            "where act_name like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Activity> findAllActivityDivide( @Param("startid") Integer startid,
                                               @Param("pagesize") Integer pagesize,
                                               @Param("query") String query);

    @Select("select * from activity a,stu_in_activity b "+
            "where b.stu_id = #{stuId} and a.act_id = b.act_id " +
            "and act_name like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Activity> findAllActivityDivideByStuId(@Param("stuId")String stuId,
                                                     @Param("startid") Integer startid,
                                                     @Param("pagesize") Integer pagesize,
                                                     @Param("query") String query);

    @Select("select count(*) from activity a,stu_in_activity b "+
            "where  b.stu_id = #{stuId} and a.act_id = b.act_id " +
            "and act_name like '%${query}%' ")
    Integer calculateTotalActivityNumberByStuId(@Param("stuId")String stuId,
                                                @Param("query") String query);

    @Select("select count(*) from activity "+
            "where act_name like '%${query}%'")
    Integer calculateTotalActivityNumber(String query);

    @Select("select soc_id from soc_of_pre where pre_id = #{preId} ")
    Integer findSocIdByPreId(@Param("preId")String preId);
                                        //'2019-07-23 09:14:55'
    @Insert("insert into activity(soc_id,act_name,act_time,position,limit_count) " +
            "values(#{socId},#{actName},#{actTime},#{position},#{limitCount})")
    void addActivity(@Param("socId") Integer socId,
                     @Param("actName") String actName,
                     @Param("actTime") Date actTime,
                     @Param("position") String position,
                     @Param("limitCount") Integer limitCount);


    @Select("select * from activity where act_id = #{actId}")
    Activity findActivityByActId(@Param("actId")String actId);


    @Update("update activity set act_name =#{actName},act_time=#{actTime},position=#{position},limit_count=#{limitCount} " +
            "where act_id = #{actId}")
    void changeActivityByActId(@Param("actId") Integer actId,
                               @Param("actName") String actName,
                               @Param("actTime") Date actTime,
                               @Param("position") String position,
                               @Param("limitCount") Integer limitCount);

    @Delete("delete from stu_in_activity where act_id=#{actId}")
    void deleteStuInActivity(@Param("actId") Integer actId);

    @Delete("delete from mem_of_act where act_id=#{actId}")
    void deleteMemOfAct(@Param("actId") Integer actId);

    @Delete("delete from activity where act_id=#{actId}")
    void deleteActivityByActId(@Param("actId") Integer actId);

    @Select("select max(act_id) from activity")
    Integer selectMaxActId();

    @Insert("insert into mem_of_act(act_id,mem_id) values(#{actId},#{memId})")
    void updateMemOfAct(Integer actId, String memId);

//    @Select("select * from ")
//    Activity findActivityByPreId(String preId);
}
