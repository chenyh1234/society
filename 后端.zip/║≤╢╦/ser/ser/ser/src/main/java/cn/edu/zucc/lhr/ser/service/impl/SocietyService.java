package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Society;
import cn.edu.zucc.lhr.ser.mapper.SocietyMapper;
import cn.edu.zucc.lhr.ser.service.ISocietyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


@Transactional
@Service
public class SocietyService extends ServiceImpl<SocietyMapper, Society> implements ISocietyService {

    @Autowired
    SocietyMapper societyMapper;

    @Override
    public Society findOneSocietyById(Integer id){return societyMapper.findOneSocietyById(id);}

    @Override
    public ArrayList<Society> findAllSociety(Integer startid, Integer count ,String query) {
        return societyMapper.findAllSociety(startid,count,query);
    }

//    @Override
//    public void changePassword(Integer id, String pwd) {
//        societyMapper.changePassword(id, pwd);
//    }

    @Override
    public void registerSociety(Integer socMemberCount,Integer socAlive,String socIntroduction, String socName) {
        societyMapper.registerSociety(socMemberCount,socAlive,socIntroduction,socName);
    }

    @Override
    public Integer getSocietyTotalNumber() {
        return societyMapper.getSocietyTotalNumber();
    }

    @Override
    public void DeleteSocietyById(Integer id) {
      societyMapper.DeleteSocietyById(id);
    }

    @Override
    public Society findOneSocietyByPreId(String preId) {
        return societyMapper.findOneSocietyByPreId(preId);
    }

    @Override
    public Integer calculateTotalNumber(String query) {
        return societyMapper.calculateTotalNumber(query);
    }

//    @Override
//    public ArrayList<Society> findSocietyByMemId(String memId,Integer startid,Integer pagesize,String query) {
//        return societyMapper.findSocietyByMemId(memId,startid,pagesize,query);
//    }

}
