package cn.edu.zucc.lhr.ser.service;

//import cn.edu.shu.xj.ser.entity.*;
import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Member;
import cn.edu.zucc.lhr.ser.entity.Notice;
import cn.edu.zucc.lhr.ser.entity.Society;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;

public interface IMemberService extends IService<Member> {

    ArrayList<Member> findAllMember();

    void changePassword(String id, String pwd);

    Member findOneMemberById(String id);

    void registerMember(String id,String name, String pwd);

    ArrayList<Member> findAllMemberByPreId(String preId, Integer startid, Integer pagesize, String query);

    void DeleteSocietyBySocIdAndMemId(String socId, String memId);

    void UpdateSocMemberCount(String socId);

    ArrayList<Activity> findAllActivityByMemId(String memId, Integer startid, Integer pagesize, String query);

    ArrayList<Society> findSocietyByMemId(String memId, Integer startid, Integer pagesize, String query);

    ArrayList<Notice> findAllNoticeDivideByMemId(String memId, Integer startid, Integer pagesize, String query);

    Integer calculateTotalMemberNumber(String preId,String query);

    Integer calculateTotalActivityNumber(String memId, String query);

    Integer calculateTotalSocietyNumber(String memId, String query);

    Integer calculateTotalNoticeNumber(String memId, String query);

    void DeleteMemberByMemId(String memId);
}
