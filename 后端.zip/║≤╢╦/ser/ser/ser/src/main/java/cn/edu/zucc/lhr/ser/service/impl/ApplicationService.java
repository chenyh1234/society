package cn.edu.zucc.lhr.ser.service.impl;


import cn.edu.zucc.lhr.ser.entity.Application;
import cn.edu.zucc.lhr.ser.mapper.ApplicationMapper;
import cn.edu.zucc.lhr.ser.service.IApplicationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Transactional
@Service
public class ApplicationService extends ServiceImpl<ApplicationMapper, Application> implements IApplicationService {

    @Autowired
    ApplicationMapper applicationMapper;

    @Override
    public Application findOneApplicationById(Integer id) {
        return applicationMapper.findOneApplicationById(id);
    }

//    @Override
//    public ArrayList<Activity>  findAllActivityDivide(Integer startid, Integer pagesize, String query){
//        return activityMapper.findAllActivityDivide(startid,pagesize,query);
//    }
}
