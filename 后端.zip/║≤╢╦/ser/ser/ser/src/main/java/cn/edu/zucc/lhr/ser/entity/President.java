package cn.edu.zucc.lhr.ser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("president")
public class President {
    @TableId
    private String preId;
    private String preName;
    private String preKey;

    President( ) {

    }
//    public Integer getPreId() {
//        return preId;
//    }
//
//    public void setPreId(Integer preId) {
//        this.preId = preId;
//    }
//
//    public String getPreName() {
//        return preName;
//    }
//
//    public void setPreName(String preName) {
//        this.preName = preName;
//    }
//
//    public String getPreKey() {
//        return preKey;
//    }
//
//    public void setPreKey(String preKey) {
//        this.preKey = preKey;
//    }
//
//    public President(Integer preId, String preKey, String preName){
//        this.preId = preId;
//        this.preName = preName;
//        this.preKey = preKey;
//    }
}
