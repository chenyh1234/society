package cn.edu.zucc.lhr.ser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("application")
public class Application {
    @TableId
    private Integer appId;
    private Integer socId;
    private String appContent;
    private String appStatus;
    private String stuName;

    public Application(){

    }
//    public Notice(Integer adminId, String adminName, String adminKey){
//        this.adminId = adminId;
//        this.adminName = adminName;
//        this.adminKey = adminKey;
//    }
}
