package cn.edu.zucc.lhr.ser.service;

import cn.edu.zucc.lhr.ser.entity.Activity;
import cn.edu.zucc.lhr.ser.entity.Application;
import cn.edu.zucc.lhr.ser.entity.President;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.ArrayList;

public interface IPresidentService extends IService<President> {

    ArrayList<President> findAllPresident();

    void changePassword(String id, String pwd);

    President findOnePresidentById(String id);

    void registerPresident(String id,String name, String pwd);

    ArrayList<Application> findApplicationByPreId(String preId, Integer startid, Integer pagesize, String query);

    Integer calculateTotalApplicationNumberByPreId(String preId, String query);

    Integer getSocIdFromSocOfPre(String preId);

//    void deleteSocOfPre(String preId, Integer socId);

    void deleteNoticeOfPre(String preId);

    void deleteNotForMem(String preId);

    void deletePresident(String preId);

    void updateSocietyNumber(Integer appId);

    void insertSocOfMem(String memId, Integer socId);

    void updateAppStatusYes(Integer appId);

    void updateAppStatusNo(Integer appId);

    ArrayList<Activity> findAllActivityDivideByPreId(String preId, Integer startid, Integer pagesize, String query);

    Integer calculateTotalActivityNumberByPreId(String preId, String query);

    void changeSocOfPre(String preId, Integer socId);

    void updateSocOfPre(String stuId, Integer socId);

    String findPreIdBySocId(Integer socId);

    void preDeleteMemOfAct(String memId);

    void preDeleteNotForMem(String memId);

    void preDeleteSocOfMember(String memId);

    void preKickMember(String memId);
}
