package cn.edu.zucc.lhr.ser.mapper;


import cn.edu.zucc.lhr.ser.entity.Student;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public interface StudentMapper extends BaseMapper<Student> {

    @Select("select * from student")
    ArrayList<Student> findAllStudent();


    @Select("select * from student where stu_id =#{stuId}")
    Student findOneStudentById(@Param("stuId") String id);


    @Update("update stu set stu_key =#{pwd} where stu_id=#{id}")
    void changePassword(@Param("id")  String id,
                       @Param("pwd")  String pwd);

    @Insert("insert into student(stu_id,stu_name,stu_key) values(#{id},#{name},#{pwd})")
    void registerStudent(@Param("id") String id,
                       @Param("name")  String name,
                       @Param("pwd")  String pwd);

    @Insert("insert into application(app_id,soc_id,app_content,app_status) values(#{appId},#{socId},#{appContent},#{appStatus})")
    void insertApplication( @Param("appId")Integer appId,
                            @Param("socId")Integer socId,
                           @Param("appContent")String appContent,
                           @Param("appStatus")String appStatus);

    @Select("select max(app_id) from application")
    Integer selectMaxAppId();

    @Insert("update application set stu_name=#{stuName} where app_id=#{appId}")
    void updateStuApplication(@Param("stuName")String stuName,
                              @Param("appId")Integer appId);

    @Select("select stu_name from student where stu_id=#{stuId}")
    String findStuNameByStuId(@Param("stuId")String stuId );

    @Insert("insert into app_of_stu(app_id,stu_id) values(#{appId},#{stuId})")
    void updateStuOfApplication(@Param("appId")Integer appId,
                                @Param("stuId")String stuId);

    @Insert("insert into stu_in_activity(act_id,stu_id) values(#{actId},#{stuId})")
    void updateStuInActivity(@Param("stuId")String stuId,
                             @Param("actId")Integer actId);

    @Update("update activity set limit_count=limit_count-1 where act_id=#{actId}")
    void updateLimitCountInActivity(@Param("actId")Integer actId);


    @Select("select * from student a,app_of_stu b " +
            "where app_id =#{appId} and a.stu_id = b.stu_id")
    Student findStudentByAppId(@Param("appId") Integer appId);

    @Select("select * from student where stu_name like '%${query}%' limit #{startid}, #{pagesize}")
    ArrayList<Student> findAllStudentDivide(@Param("startid")Integer startid,
                                            @Param("pagesize")Integer pagesize,
                                            @Param("query")String query);

    @Select("select count(*) from student where stu_name like '%${query}%'")
    Integer calculateTotalStudentNumber(@Param("query")String query);
}
