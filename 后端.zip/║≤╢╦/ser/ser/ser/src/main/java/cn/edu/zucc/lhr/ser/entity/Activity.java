package cn.edu.zucc.lhr.ser.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@TableName("activity")
public class Activity {
    @TableId
    private Integer actId;
    private Integer socId;
    private String actName;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss" )
    private Date actTime;
    private String position;
    private Integer limitCount;

    public Activity(){

    }
//    public Activity(Integer adminId, String adminName, String adminKey){
//        this.adminId = adminId;
//        this.adminName = adminName;
//        this.adminKey = adminKey;
//    }
}
